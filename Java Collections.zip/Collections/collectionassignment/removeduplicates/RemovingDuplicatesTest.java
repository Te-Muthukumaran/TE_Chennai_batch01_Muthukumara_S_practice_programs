package com.te.collectionassignment.removeduplicates;

public class RemovingDuplicatesTest {

	public static void main(String[] args) {
		
		RemovingDuplicatesArrayList ref = new RemovingDuplicatesArrayList();
		ref.rd();
	}
}
