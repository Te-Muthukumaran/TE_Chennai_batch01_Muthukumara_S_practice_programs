package com.te.collectionassignment.occurance;

public class OccurancesTest {

	public static void main(String[] args) {
		
		Occurances ref = new Occurances();
		ref.occ();
	}
}
