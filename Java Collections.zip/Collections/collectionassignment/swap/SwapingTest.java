package com.te.collectionassignment.swap;

public class SwapingTest {

	public static void main(String[] args) {
		
		Swaping ref = new Swaping();
		ref.swa();
	}
}
