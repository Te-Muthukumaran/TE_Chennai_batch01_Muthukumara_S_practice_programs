package com.te.collectionassignment.copyarraylist;

public class Copy1Test {

	public static void main(String[] args) {
		
		Copy1 ref = new Copy1();
		ref.cc();
	}
}
