package com.te.collectionassignment.retriveelement;

public class RetriveTest {

	public static void main(String[] args) {
		
		Retrive ref = new Retrive();
		ref.ret();
	}
}
