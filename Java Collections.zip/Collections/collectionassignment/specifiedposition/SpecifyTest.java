package com.te.collectionassignment.specifiedposition;

public class SpecifyTest {

	public static void main(String[] args) {
		
		Specify ref = new Specify();
		ref.spe();
	}
}
