package com.te.collectionassignment.arraytolinked;

public class ArrayToLinkedTest {

	public static void main(String[] args) {
		
		ArrayToLinked ref = new ArrayToLinked();
		ref.atl();
	}
}
